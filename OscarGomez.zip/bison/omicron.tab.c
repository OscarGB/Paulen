/* A Bison parser, made by GNU Bison 3.0.4.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "3.0.4"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* Copy the first part of user declarations.  */
#line 1 "bison/omicron.y" /* yacc.c:339  */

#include "generacion.h"
#include "omicron.h"
#include "tabla_simbolos_clases.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TIPO_RETORNO numero_atributos_clase
#define MAX_TAM_VECTOR 256

extern int linea;
extern int columna;
extern FILE * salida;
extern FILE * sintactico;

simbolos_p simbolos = NULL;
simbolo_p s =NULL;
simbolo_p * simbolos_main=NULL;
char id_ambito[100];
int etiqueta = 0;
int getiqueta =0;
int etiquetas[100];
int cima_etiquetas = 0;
int contador_variables=0;
char * etiqueta_nombre_actual=NULL;
int tipo_actual = 0;
int clase_actual = 0;
int valor_actual = 0;
int num_parametros_actual=0;
int tipos_parametros[100];
int num_variables_locales_actual=0;
int pos_variable_local_actual=0;
int pos_parametro_actual = 0;
char* nombre_actual_simbolo=NULL;
char* nombre_funcion;
char nombres_parametros[100][100];
int  num_parametros_llamada_actual = 0;
int fn_return = 0;
int en_explist = 0;
int tipo_retorno = 0;
int tamanio_vector_actual =0;
char* nombre_prefijo;
int flag_if=0;

int etiqueta_exponencial = 0;
char switch_var[256];
int case_cont = 0;
int switch_etiqueta;
int ultimo;

void escribe_cabecera (FILE * salida);
void escribe_variables (FILE * salida, int tipo, char* nombre, int tamanio);
void gc_suma_enteros(FILE *salida, int es_direccion_op1, int es_direccion_op2);
void gc_resta_enteros(FILE *salida, int es_direccion_op1, int es_direccion_op2);
void gc_exponencial_enteros(FILE *salida, int es_direccion_op1, int es_direccion_op2, int etiqueta_exponencial);
void gc_division_enteros(FILE *salida, int es_direccion_op1, int es_direccion_op2);
void gc_producto_enteros(FILE *salida, int es_direccion_op1, int es_direccion_op2);
void gc_negacion_entero(FILE *salida, int es_direccion_op1);
void gc_and_logico(FILE *salida, int es_direccion_op1, int es_direccion_op2);
void gc_or_logico(FILE *salida, int es_direccion_op1, int es_direccion_op2);
void gc_not_logico(FILE *salida, int es_direccion_op1, int etiqueta);
void gc_igual(FILE *salida, int es_direccion_op1, int es_direccion_op2, int etiqueta);
void gc_distinto(FILE *salida, int es_direccion_op1, int es_direccion_op2, int etiqueta);
void gc_menorigual(FILE *salida, int es_direccion_op1, int es_direccion_op2, int etiqueta);
void gc_mayorigual(FILE *salida, int es_direccion_op1, int es_direccion_op2, int etiqueta);
void gc_menor(FILE *salida, int es_direccion_op1, int es_direccion_op2, int etiqueta);
void gc_mayor(FILE *salida, int es_direccion_op1, int es_direccion_op2, int etiqueta);
void gc_vectores_indice(FILE *salida, int es_direccion_op1, char *lexema, int tam_vector);
void gc_printf_vectores(FILE *salida, int etiqueta, int tamanio, int tipo);
void gc_printf(FILE *salida, int es_direccion_op1, int tipo);
void gc_asigexp_ident(FILE *salida, int es_direccion_op1, char *lexema);
void gc_ifthenelse_inicio(FILE * salida, int exp_es_variable, int etiqueta);
void gc_ifthen_inicio(FILE * salida, int exp_es_variable, int etiqueta);
void gc_ifthen_fin(FILE* salida, int etiqueta);
void gc_ifthenelse_fin_then(FILE* salida, int etiqueta);
void gc_ifthenelse_fin( FILE * salida, int etiqueta);
void gc_ifthenelse_fin( FILE * salida, int etiqueta);
void asignarDestinoPila(FILE* salida, int es_variable, char * eax, char * ebx);
void gc_scanf_funcion(FILE *salida, int num_param_actual, int posicion_parametro, int categoria, int tipo);
void gc_lectura(FILE * salida, char * nombre, int tipo);
void gc_inicio_cuerpo_funcion (FILE *salida, char * lexema, int num_variable_locales);
void gc_final_cuerpo_funcion (FILE *salida, int esdireccion);
void gc_identificador_asignacion_local(FILE *salida, int es_direccion, int categoria, int numero_param, int posicion);
void gc_asignar_exp_a_elementovector(FILE *salida, int es_direccion_op1);
void gc_llamarfuncion (FILE *salida, char * lexema, int num_parametros);
void gc_escribirParametro(FILE *salida, int posicion_parametro, int num_parametros_actual);
void gc_escribirVariableLocal(FILE *salida,int posicion_variable_local);
void gc_escribir_elemento_vector(FILE *salida, int es_direccion_op1, char *lexema, int tam_vector);
void gc_while_fin(FILE * salida,int etiqueta);
void gc_while_inicio(FILE * salida,int  etiqueta);
void gc_while_exp_pila (FILE * salida, int exp_es_variable, int etiqueta);
void imprimir_error(FILE * salida);
void yyerror();


#line 163 "bison/omicron.tab.c" /* yacc.c:339  */

# ifndef YY_NULLPTR
#  if defined __cplusplus && 201103L <= __cplusplus
#   define YY_NULLPTR nullptr
#  else
#   define YY_NULLPTR 0
#  endif
# endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* In a future release of Bison, this section will be replaced
   by #include "omicron.tab.h".  */
#ifndef YY_YY_BISON_OMICRON_TAB_H_INCLUDED
# define YY_YY_BISON_OMICRON_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    TOK_NONE = 258,
    TOK_CLASS = 259,
    TOK_INHERITS = 260,
    TOK_INSTANCE_OF = 261,
    TOK_DISCARD = 262,
    TOK_ITSELF = 263,
    TOK_FLECHA = 264,
    TOK_HIDDEN = 265,
    TOK_SECRET = 266,
    TOK_EXPOSED = 267,
    TOK_UNIQUE = 268,
    TOK_FUNCTION = 269,
    TOK_MAIN = 270,
    TOK_INT = 271,
    TOK_BOOLEAN = 272,
    TOK_ARRAY = 273,
    TOK_IF = 274,
    TOK_ELSE = 275,
    TOK_WHILE = 276,
    TOK_SCANF = 277,
    TOK_PRINTF = 278,
    TOK_RETURN = 279,
    TOK_IGUAL = 280,
    TOK_DISTINTO = 281,
    TOK_MENORIGUAL = 282,
    TOK_MAYORIGUAL = 283,
    TOK_OR = 284,
    TOK_AND = 285,
    TOK_FOR = 286,
    TOK_SWITCH = 287,
    TOK_CASE = 288,
    TOK_DEFAULT = 289,
    TOK_BREAK = 290,
    TOK_FLOAT = 291,
    TOK_MALLOC = 292,
    TOK_CPRINTF = 293,
    TOK_FREE = 294,
    TOK_SET = 295,
    TOK_OF = 296,
    TOK_UNION = 297,
    TOK_INTERSECTION = 298,
    TOK_ADD = 299,
    TOK_CLEAR = 300,
    TOK_SIZE = 301,
    TOK_CONTAINS = 302,
    TOK_CONSTANTE_REAL = 303,
    TOK_TRUE = 304,
    TOK_FALSE = 305,
    TOK_IDENTIFICADOR = 306,
    TOK_CONSTANTE_ENTERA = 307,
    MENOSU = 308,
    TOK_EXP = 309
  };
#endif
/* Tokens.  */
#define TOK_NONE 258
#define TOK_CLASS 259
#define TOK_INHERITS 260
#define TOK_INSTANCE_OF 261
#define TOK_DISCARD 262
#define TOK_ITSELF 263
#define TOK_FLECHA 264
#define TOK_HIDDEN 265
#define TOK_SECRET 266
#define TOK_EXPOSED 267
#define TOK_UNIQUE 268
#define TOK_FUNCTION 269
#define TOK_MAIN 270
#define TOK_INT 271
#define TOK_BOOLEAN 272
#define TOK_ARRAY 273
#define TOK_IF 274
#define TOK_ELSE 275
#define TOK_WHILE 276
#define TOK_SCANF 277
#define TOK_PRINTF 278
#define TOK_RETURN 279
#define TOK_IGUAL 280
#define TOK_DISTINTO 281
#define TOK_MENORIGUAL 282
#define TOK_MAYORIGUAL 283
#define TOK_OR 284
#define TOK_AND 285
#define TOK_FOR 286
#define TOK_SWITCH 287
#define TOK_CASE 288
#define TOK_DEFAULT 289
#define TOK_BREAK 290
#define TOK_FLOAT 291
#define TOK_MALLOC 292
#define TOK_CPRINTF 293
#define TOK_FREE 294
#define TOK_SET 295
#define TOK_OF 296
#define TOK_UNION 297
#define TOK_INTERSECTION 298
#define TOK_ADD 299
#define TOK_CLEAR 300
#define TOK_SIZE 301
#define TOK_CONTAINS 302
#define TOK_CONSTANTE_REAL 303
#define TOK_TRUE 304
#define TOK_FALSE 305
#define TOK_IDENTIFICADOR 306
#define TOK_CONSTANTE_ENTERA 307
#define MENOSU 308
#define TOK_EXP 309

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED

union YYSTYPE
{
#line 98 "bison/omicron.y" /* yacc.c:355  */

	tipo_atributos atributos;

#line 315 "bison/omicron.tab.c" /* yacc.c:355  */
};

typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_BISON_OMICRON_TAB_H_INCLUDED  */

/* Copy the second part of user declarations.  */

#line 332 "bison/omicron.tab.c" /* yacc.c:358  */

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif

#ifndef YY_ATTRIBUTE
# if (defined __GNUC__                                               \
      && (2 < __GNUC__ || (__GNUC__ == 2 && 96 <= __GNUC_MINOR__)))  \
     || defined __SUNPRO_C && 0x5110 <= __SUNPRO_C
#  define YY_ATTRIBUTE(Spec) __attribute__(Spec)
# else
#  define YY_ATTRIBUTE(Spec) /* empty */
# endif
#endif

#ifndef YY_ATTRIBUTE_PURE
# define YY_ATTRIBUTE_PURE   YY_ATTRIBUTE ((__pure__))
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# define YY_ATTRIBUTE_UNUSED YY_ATTRIBUTE ((__unused__))
#endif

#if !defined _Noreturn \
     && (!defined __STDC_VERSION__ || __STDC_VERSION__ < 201112)
# if defined _MSC_VER && 1200 <= _MSC_VER
#  define _Noreturn __declspec (noreturn)
# else
#  define _Noreturn YY_ATTRIBUTE ((__noreturn__))
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(E) ((void) (E))
#else
# define YYUSE(E) /* empty */
#endif

#if defined __GNUC__ && 407 <= __GNUC__ * 100 + __GNUC_MINOR__
/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN \
    _Pragma ("GCC diagnostic push") \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")\
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# define YY_IGNORE_MAYBE_UNINITIALIZED_END \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif


#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYSIZE_T yynewbytes;                                            \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / sizeof (*yyptr);                          \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, (Count) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYSIZE_T yyi;                         \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  3
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   313

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  73
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  63
/* YYNRULES -- Number of rules.  */
#define YYNRULES  127
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  259

/* YYTRANSLATE[YYX] -- Symbol number corresponding to YYX as returned
   by yylex, with out-of-bounds checking.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   309

#define YYTRANSLATE(YYX)                                                \
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, without out-of-bounds checking.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    58,     2,     2,     2,     2,     2,     2,
      66,    67,    55,    53,    65,    54,    68,    56,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,    69,    62,
      72,    70,    71,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    63,     2,    64,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    60,     2,    61,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    57,    59
};

#if YYDEBUG
  /* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   217,   217,   223,   236,   241,   246,   256,   261,   267,
     273,   280,   284,   289,   294,   299,   303,   307,   311,   316,
     322,   328,   336,   341,   348,   353,   359,   365,   373,   379,
     391,   396,   402,   408,   413,   436,   463,   473,   489,   494,
     500,   506,   511,   517,   522,   528,   534,   539,   544,   550,
     555,   561,   566,   571,   576,   581,   586,   591,   597,   603,
     608,   613,   618,   626,   633,   657,   666,   671,   683,   687,
     691,   695,   702,   707,   742,   754,   759,   764,   770,   801,
     808,   815,   823,   841,   849,   864,   873,   901,   907,   915,
     921,   940,   946,   958,   970,   983,   995,  1007,  1019,  1031,
    1043,  1056,  1084,  1091,  1098,  1105,  1112,  1164,  1169,  1176,
    1181,  1187,  1196,  1202,  1210,  1215,  1228,  1241,  1254,  1267,
    1280,  1294,  1301,  1309,  1317,  1326,  1336,  1345
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || 0
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "TOK_NONE", "TOK_CLASS", "TOK_INHERITS",
  "TOK_INSTANCE_OF", "TOK_DISCARD", "TOK_ITSELF", "TOK_FLECHA",
  "TOK_HIDDEN", "TOK_SECRET", "TOK_EXPOSED", "TOK_UNIQUE", "TOK_FUNCTION",
  "TOK_MAIN", "TOK_INT", "TOK_BOOLEAN", "TOK_ARRAY", "TOK_IF", "TOK_ELSE",
  "TOK_WHILE", "TOK_SCANF", "TOK_PRINTF", "TOK_RETURN", "TOK_IGUAL",
  "TOK_DISTINTO", "TOK_MENORIGUAL", "TOK_MAYORIGUAL", "TOK_OR", "TOK_AND",
  "TOK_FOR", "TOK_SWITCH", "TOK_CASE", "TOK_DEFAULT", "TOK_BREAK",
  "TOK_FLOAT", "TOK_MALLOC", "TOK_CPRINTF", "TOK_FREE", "TOK_SET",
  "TOK_OF", "TOK_UNION", "TOK_INTERSECTION", "TOK_ADD", "TOK_CLEAR",
  "TOK_SIZE", "TOK_CONTAINS", "TOK_CONSTANTE_REAL", "TOK_TRUE",
  "TOK_FALSE", "TOK_IDENTIFICADOR", "TOK_CONSTANTE_ENTERA", "'+'", "'-'",
  "'*'", "'/'", "MENOSU", "'!'", "TOK_EXP", "'{'", "'}'", "';'", "'['",
  "']'", "','", "'('", "')'", "'.'", "':'", "'='", "'>'", "'<'", "$accept",
  "programa", "escritura_TS", "escritura_main", "final_programa",
  "inicioTabla", "declaraciones", "declaracion", "modificadores_acceso",
  "clase", "declaracion_clase", "modificadores_clase", "clase_escalar",
  "tipo", "clase_objeto", "clase_vector", "identificadores", "funciones",
  "fn_name", "fn_complete_name", "fn_declaration", "funcion",
  "tipo_retorno", "parametros_funcion", "resto_parametros_funcion",
  "parametro_funcion", "declaraciones_funcion", "sentencias", "sentencia",
  "sentencia_simple", "destruir_objeto", "bloque", "for", "for_medio",
  "for_inicio", "switch", "switch_ini", "casos", "caso", "cabecera",
  "final_caso", "asignacion", "elemento_vector", "condicional",
  "if_exp_sentencias", "if_exp", "bucle", "while_exp", "while", "lectura",
  "escritura", "idf_llamada_funcion", "retorno_funcion", "exp",
  "identificador_clase", "lista_expresiones", "resto_lista_expresiones",
  "comparacion", "constante", "constante_logica", "constante_entera",
  "idpf", "identificador", YY_NULLPTR
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[NUM] -- (External) token number corresponding to the
   (internal) symbol number NUM (which must be that of a token).  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,    43,    45,    42,    47,   308,    33,   309,
     123,   125,    59,    91,    93,    44,    40,    41,    46,    58,
      61,    62,    60
};
# endif

#define YYPACT_NINF -142

#define yypact_value_is_default(Yystate) \
  (!!((Yystate) == (-142)))

#define YYTABLE_NINF -110

#define yytable_value_is_error(Yytable_value) \
  0

  /* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
     STATE-NUM.  */
static const yytype_int16 yypact[] =
{
    -142,    24,    -3,  -142,   -29,   191,    20,    25,    26,  -142,
    -142,   167,     2,  -142,  -142,  -142,    22,  -142,  -142,  -142,
      -6,   -10,     1,    -2,    63,  -142,  -142,  -142,  -142,   191,
    -142,     6,    13,   227,    22,    18,    31,  -142,    28,    34,
    -142,    50,    12,   227,    -6,   167,    66,  -142,    48,    62,
      81,   108,    61,    68,    70,    23,    77,   227,    78,  -142,
    -142,  -142,   227,    83,  -142,   116,  -142,    80,  -142,   132,
     227,  -142,   227,   108,  -142,  -142,  -142,    86,  -142,   103,
    -142,  -142,     1,     3,  -142,  -142,   105,  -142,   112,   100,
     107,  -142,  -142,  -142,   108,  -142,   110,  -142,  -142,  -142,
      67,  -142,   108,   108,   108,  -142,   104,   250,   113,  -142,
    -142,  -142,  -142,   250,    -7,   124,   108,   108,    -1,  -142,
    -142,  -142,   115,   108,   140,   133,   116,   227,    71,   145,
     146,   147,    29,   142,   148,  -142,     1,   191,  -142,   152,
    -142,  -142,  -142,    -6,  -142,   201,   150,   150,   161,   139,
     108,   108,   108,   108,   108,   108,   108,   108,   168,   -49,
    -142,   153,   151,   236,   208,   155,   185,   250,  -142,   170,
     177,   171,  -142,  -142,   209,  -142,   192,   250,   227,   225,
    -142,   187,   -44,  -142,   193,    22,  -142,   107,   210,   108,
     108,   108,   108,  -142,   108,   108,  -142,   202,   109,   150,
     109,   109,   150,   150,   150,   186,   220,   212,  -142,   108,
    -142,  -142,   211,   223,  -142,   213,   215,   221,  -142,   108,
     108,   191,   222,  -142,  -142,   250,   250,   250,   250,   250,
     250,  -142,   108,   206,  -142,   208,   108,   231,  -142,   108,
    -142,   218,   250,    22,  -142,   219,  -142,   226,   234,   229,
    -142,   233,  -142,  -142,   230,  -142,  -142,   228,  -142
};

  /* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
     Performed when YYTABLE does not specify something else to do.  Zero
     means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       6,     0,     0,     1,     0,    11,    15,    16,    17,    18,
       3,     7,    24,    12,    13,    14,    33,     8,    26,    27,
       0,     0,     0,     0,     0,    19,    25,    21,    20,    11,
       4,     0,     0,     0,    33,     0,     0,   127,     0,    30,
      10,     0,     0,     0,    41,    46,     0,   110,     0,     0,
       0,     0,     0,     0,     0,   109,     0,    47,     0,    57,
      50,    61,     0,     0,    62,     0,    51,     0,    59,     0,
       0,    60,     0,     0,    52,    53,    54,     0,    32,     0,
      28,     9,     0,     0,    38,    39,     0,     5,     0,     0,
      43,    45,    36,    58,     0,    85,    86,    87,   123,   124,
     101,   125,     0,     0,     0,   105,     0,    88,     0,   102,
     121,   122,    91,    90,     0,     0,     0,   112,     0,    37,
      48,    49,     0,     0,     0,     0,    69,     0,     0,     0,
       0,     0,     0,     0,     0,    31,     0,    11,    34,     0,
     126,    44,    35,     0,    40,     0,    97,   100,     0,     0,
     112,     0,     0,     0,     0,     0,     0,     0,     0,   109,
      65,     0,     0,     0,   114,     0,     0,    73,    63,     0,
       0,     0,    66,    68,     0,    70,     0,    74,     0,    79,
      83,     0,     0,    29,     0,    33,     2,    43,     0,     0,
       0,     0,     0,   103,     0,     0,   104,     0,    99,    98,
      92,    93,    96,    95,    94,   108,     0,     0,    78,     0,
     111,    56,     0,     0,    71,     0,     0,     0,    84,   112,
       0,    11,     0,    42,    82,   115,   116,   118,   117,   119,
     120,   106,   112,     0,    67,   114,   112,     0,    72,   112,
      80,     0,    77,    33,    23,     0,   113,     0,     0,     0,
      55,     0,   107,    76,     0,    75,    22,     0,    64
};

  /* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -142,  -142,  -142,  -142,  -142,  -142,   -11,  -142,   269,  -142,
    -142,  -142,  -142,    82,  -142,  -142,   -65,   -32,  -142,  -142,
    -142,  -142,  -142,  -142,   114,   156,  -142,   -30,  -142,  -142,
    -142,  -142,  -142,  -142,  -142,  -142,  -142,   176,  -142,  -142,
    -142,   194,   -27,  -142,  -142,  -142,  -142,  -142,  -142,  -142,
    -142,  -142,  -142,   -48,     4,  -141,    72,   188,  -142,  -142,
     189,  -142,  -142
};

  /* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,     1,    16,    43,   139,     2,    10,    11,    12,    22,
      23,    24,    25,    88,    27,    28,    38,    30,    31,    32,
      33,    34,    86,    89,   144,    90,    92,    56,    57,    58,
      59,    60,    61,    62,    63,    64,    65,   125,   126,   127,
     175,    66,   105,    68,    69,    70,    71,    72,    73,    74,
      75,   106,    76,   164,   108,   165,   210,   149,   109,   110,
     111,   141,    39
};

  /* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
     positive, shift that token.  If negative, reduce the rule whose
     number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
      17,    47,    78,   107,   113,   166,    67,    47,   136,   197,
      18,    19,     4,    87,   116,    84,    67,   135,    18,    19,
      20,   118,   219,    97,     3,   132,   220,   120,    18,    19,
      67,     5,   122,    13,    91,    67,    29,    77,    14,    15,
     130,    36,   131,    67,   159,    67,   145,    77,    98,    99,
     100,   101,    37,   102,   146,   147,   148,   103,   151,   152,
      40,    77,    21,   137,   112,   104,    77,    41,   163,    47,
     167,   184,    44,    45,    77,   169,    77,   176,   241,    47,
     177,    79,   153,   154,   155,   156,   116,    67,   157,   117,
      81,   245,    80,   118,    26,   247,   181,   174,   249,    82,
      67,    83,    35,   198,   199,   200,   201,   202,   203,   204,
      98,    99,   100,   101,    94,   102,    47,    93,   161,   103,
      98,    99,   100,   101,    85,   102,   185,   104,    95,   103,
     116,    77,    96,   -89,   114,  -109,   115,   104,   119,   152,
     121,   225,   226,   227,   228,   123,   229,   230,   217,   124,
     128,    67,   129,   222,   133,   134,   138,    98,    99,   100,
     101,   235,   102,   140,   155,   156,   103,   142,   157,   143,
     150,   -11,   242,   116,   104,   162,   168,     6,     7,     8,
       9,   158,    77,   -11,   -11,   -11,   189,   190,   191,   192,
     151,   152,   101,   182,   172,   189,   190,   191,   192,   151,
     152,     6,     7,     8,     9,   178,   196,   179,   180,   157,
     243,   251,   183,   186,   153,   154,   155,   156,   207,   205,
     157,   206,   211,   153,   154,   155,   156,   -11,   193,   157,
     151,   152,   194,   195,    46,    47,   212,   151,   152,   213,
     214,   194,   195,   216,   215,   -81,    48,   218,    49,    50,
      51,    52,   232,   221,   153,   154,   155,   156,    53,    54,
     157,   153,   154,   155,   156,   151,   152,   157,   188,   231,
     224,   233,   234,   209,   237,   238,   220,   236,    55,   151,
     152,   239,   240,   244,   248,   250,   252,   254,   258,   153,
     154,   155,   156,   253,   256,   157,   255,   257,    42,   187,
     208,   223,   173,   153,   154,   155,   156,   246,   160,   157,
       0,   170,     0,   171
};

static const yytype_int16 yycheck[] =
{
      11,     8,    34,    51,    52,     6,    33,     8,     5,   150,
      16,    17,    15,    43,    63,     3,    43,    82,    16,    17,
      18,    70,    66,    50,     0,    73,    70,    57,    16,    17,
      57,    60,    62,    13,    45,    62,    14,    33,    13,    13,
      70,    51,    72,    70,    51,    72,    94,    43,    49,    50,
      51,    52,    51,    54,   102,   103,   104,    58,    29,    30,
      62,    57,    60,    60,     3,    66,    62,     4,   116,     8,
     118,   136,    66,    60,    70,   123,    72,     6,   219,     8,
     128,    63,    53,    54,    55,    56,    63,   114,    59,    66,
      62,   232,    61,    70,    12,   236,    67,   127,   239,    65,
     127,    51,    20,   151,   152,   153,   154,   155,   156,   157,
      49,    50,    51,    52,    66,    54,     8,    51,   114,    58,
      49,    50,    51,    52,    42,    54,   137,    66,    66,    58,
      63,   127,    51,    66,    66,    68,    66,    66,    61,    30,
      62,   189,   190,   191,   192,    62,   194,   195,   178,    33,
      70,   178,    20,   185,    68,    52,    51,    49,    50,    51,
      52,   209,    54,    51,    55,    56,    58,    67,    59,    62,
      66,     4,   220,    63,    66,    51,    61,    10,    11,    12,
      13,    68,   178,    16,    17,    18,    25,    26,    27,    28,
      29,    30,    52,    51,    61,    25,    26,    27,    28,    29,
      30,    10,    11,    12,    13,    60,    67,    61,    61,    59,
     221,   243,    64,    61,    53,    54,    55,    56,    67,    51,
      59,    68,    67,    53,    54,    55,    56,    60,    67,    59,
      29,    30,    71,    72,     7,     8,    51,    29,    30,    62,
      69,    71,    72,    51,    35,    20,    19,    60,    21,    22,
      23,    24,    66,    60,    53,    54,    55,    56,    31,    32,
      59,    53,    54,    55,    56,    29,    30,    59,    67,    67,
      60,    51,    60,    65,    51,    62,    70,    66,    51,    29,
      30,    66,    61,    61,    53,    67,    67,    53,    60,    53,
      54,    55,    56,    67,    61,    59,    67,    67,    29,   143,
      64,   187,   126,    53,    54,    55,    56,   235,   114,    59,
      -1,   123,    -1,   124
};

  /* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
     symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,    74,    78,     0,    15,    60,    10,    11,    12,    13,
      79,    80,    81,    13,    13,    13,    75,    79,    16,    17,
      18,    60,    82,    83,    84,    85,    86,    87,    88,    14,
      90,    91,    92,    93,    94,    86,    51,    51,    89,   135,
      62,     4,    81,    76,    66,    60,     7,     8,    19,    21,
      22,    23,    24,    31,    32,    51,   100,   101,   102,   103,
     104,   105,   106,   107,   108,   109,   114,   115,   116,   117,
     118,   119,   120,   121,   122,   123,   125,   127,    90,    63,
      61,    62,    65,    51,     3,    86,    95,   100,    86,    96,
      98,    79,    99,    51,    66,    66,    51,   115,    49,    50,
      51,    52,    54,    58,    66,   115,   124,   126,   127,   131,
     132,   133,     3,   126,    66,    66,    63,    66,    70,    61,
     100,    62,   100,    62,    33,   110,   111,   112,    70,    20,
     100,   100,   126,    68,    52,    89,     5,    60,    51,    77,
      51,   134,    67,    62,    97,   126,   126,   126,   126,   130,
      66,    29,    30,    53,    54,    55,    56,    59,    68,    51,
     114,   127,    51,   126,   126,   128,     6,   126,    61,   126,
     130,   133,    61,   110,   100,   113,     6,   126,    60,    61,
      61,    67,    51,    64,    89,    79,    61,    98,    67,    25,
      26,    27,    28,    67,    71,    72,    67,   128,   126,   126,
     126,   126,   126,   126,   126,    51,    68,    67,    64,    65,
     129,    67,    51,    62,    69,    35,    51,   100,    60,    66,
      70,    60,    90,    97,    60,   126,   126,   126,   126,   126,
     126,    67,    66,    51,    60,   126,    66,    51,    62,    66,
      61,   128,   126,    79,    61,   128,   129,   128,    53,   128,
      67,    90,    67,    67,    53,    67,    61,    67,    60
};

  /* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    73,    74,    75,    76,    77,    78,    79,    79,    80,
      80,    81,    81,    81,    81,    81,    81,    81,    81,    82,
      82,    82,    83,    83,    84,    85,    86,    86,    87,    88,
      89,    89,    90,    90,    91,    92,    93,    94,    95,    95,
      96,    96,    97,    97,    98,    99,    99,   100,   100,   101,
     101,   102,   102,   102,   102,   102,   102,   102,   103,   104,
     104,   104,   104,   105,   106,   107,   108,   109,   110,   110,
     111,   112,   113,   114,   114,   114,   114,   114,   115,   116,
     116,   117,   118,   119,   120,   121,   122,   122,   123,   124,
     125,   125,   126,   126,   126,   126,   126,   126,   126,   126,
     126,   126,   126,   126,   126,   126,   126,   126,   126,   127,
     127,   128,   128,   129,   129,   130,   130,   130,   130,   130,
     130,   131,   131,   132,   132,   133,   134,   135
};

  /* YYR2[YYN] -- Number of symbols on the right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,    10,     0,     0,     0,     0,     1,     2,     4,
       3,     0,     2,     2,     2,     1,     1,     1,     1,     1,
       1,     1,     9,     7,     0,     1,     1,     1,     3,     5,
       1,     3,     2,     0,     4,     4,     3,     3,     1,     1,
       2,     0,     3,     0,     2,     1,     0,     1,     2,     2,
       1,     1,     1,     1,     1,     6,     4,     1,     2,     1,
       1,     1,     1,     3,     9,     3,     3,     5,     2,     1,
       2,     3,     3,     3,     3,     7,     7,     5,     4,     3,
       5,     3,     5,     3,     4,     2,     2,     2,     2,     1,
       2,     2,     3,     3,     3,     3,     3,     2,     3,     3,
       2,     1,     1,     3,     3,     1,     4,     6,     3,     1,
       1,     2,     0,     3,     0,     3,     3,     3,     3,     3,
       3,     1,     1,     1,     1,     1,     1,     1
};


#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)
#define YYEMPTY         (-2)
#define YYEOF           0

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                  \
do                                                              \
  if (yychar == YYEMPTY)                                        \
    {                                                           \
      yychar = (Token);                                         \
      yylval = (Value);                                         \
      YYPOPSTACK (yylen);                                       \
      yystate = *yyssp;                                         \
      goto yybackup;                                            \
    }                                                           \
  else                                                          \
    {                                                           \
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;                                                  \
    }                                                           \
while (0)

/* Error token number */
#define YYTERROR        1
#define YYERRCODE       256



/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)

/* This macro is provided for backward compatibility. */
#ifndef YY_LOCATION_PRINT
# define YY_LOCATION_PRINT(File, Loc) ((void) 0)
#endif


# define YY_SYMBOL_PRINT(Title, Type, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Type, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*----------------------------------------.
| Print this symbol's value on YYOUTPUT.  |
`----------------------------------------*/

static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
{
  FILE *yyo = yyoutput;
  YYUSE (yyo);
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
  YYUSE (yytype);
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyoutput, "%s %s (",
             yytype < YYNTOKENS ? "token" : "nterm", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yytype_int16 *yybottom, yytype_int16 *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yytype_int16 *yyssp, YYSTYPE *yyvsp, int yyrule)
{
  unsigned long int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       yystos[yyssp[yyi + 1 - yynrhs]],
                       &(yyvsp[(yyi + 1) - (yynrhs)])
                                              );
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
yystrlen (const char *yystr)
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
yystpcpy (char *yydest, const char *yysrc)
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
        switch (*++yyp)
          {
          case '\'':
          case ',':
            goto do_not_strip_quotes;

          case '\\':
            if (*++yyp != '\\')
              goto do_not_strip_quotes;
            /* Fall through.  */
          default:
            if (yyres)
              yyres[yyn] = *yyp;
            yyn++;
            break;

          case '"':
            if (yyres)
              yyres[yyn] = '\0';
            return yyn;
          }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return 1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return 2 if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYSIZE_T *yymsg_alloc, char **yymsg,
                yytype_int16 *yyssp, int yytoken)
{
  YYSIZE_T yysize0 = yytnamerr (YY_NULLPTR, yytname[yytoken]);
  YYSIZE_T yysize = yysize0;
  enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
  /* Internationalized format string. */
  const char *yyformat = YY_NULLPTR;
  /* Arguments of yyformat. */
  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
  /* Number of reported tokens (one for the "unexpected", one per
     "expected"). */
  int yycount = 0;

  /* There are many possibilities here to consider:
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yytoken != YYEMPTY)
    {
      int yyn = yypact[*yyssp];
      yyarg[yycount++] = yytname[yytoken];
      if (!yypact_value_is_default (yyn))
        {
          /* Start YYX at -YYN if negative to avoid negative indexes in
             YYCHECK.  In other words, skip the first -YYN actions for
             this state because they are default actions.  */
          int yyxbegin = yyn < 0 ? -yyn : 0;
          /* Stay within bounds of both yycheck and yytname.  */
          int yychecklim = YYLAST - yyn + 1;
          int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
          int yyx;

          for (yyx = yyxbegin; yyx < yyxend; ++yyx)
            if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR
                && !yytable_value_is_error (yytable[yyx + yyn]))
              {
                if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                  {
                    yycount = 1;
                    yysize = yysize0;
                    break;
                  }
                yyarg[yycount++] = yytname[yyx];
                {
                  YYSIZE_T yysize1 = yysize + yytnamerr (YY_NULLPTR, yytname[yyx]);
                  if (! (yysize <= yysize1
                         && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
                    return 2;
                  yysize = yysize1;
                }
              }
        }
    }

  switch (yycount)
    {
# define YYCASE_(N, S)                      \
      case N:                               \
        yyformat = S;                       \
      break
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
# undef YYCASE_
    }

  {
    YYSIZE_T yysize1 = yysize + yystrlen (yyformat);
    if (! (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
      return 2;
    yysize = yysize1;
  }

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return 1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yyarg[yyi++]);
          yyformat += 2;
        }
      else
        {
          yyp++;
          yyformat++;
        }
  }
  return 0;
}
#endif /* YYERROR_VERBOSE */

/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
{
  YYUSE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YYUSE (yytype);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}




/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;


/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    int yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       'yyss': related to states.
       'yyvs': related to semantic values.

       Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yytype_int16 yyssa[YYINITDEPTH];
    yytype_int16 *yyss;
    yytype_int16 *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    YYSIZE_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken = 0;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yyssp = yyss = yyssa;
  yyvsp = yyvs = yyvsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */
  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        YYSTYPE *yyvs1 = yyvs;
        yytype_int16 *yyss1 = yyss;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * sizeof (*yyssp),
                    &yyvs1, yysize * sizeof (*yyvsp),
                    &yystacksize);

        yyss = yyss1;
        yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yytype_int16 *yyss1 = yyss;
        union yyalloc *yyptr =
          (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
        if (! yyptr)
          goto yyexhaustedlab;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
                  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token.  */
  yychar = YYEMPTY;

  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:
#line 218 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico, ";R: programa: TOK_MAIN '{' declaraciones funciones sentencias '}'\n");
		}
#line 1622 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 3:
#line 223 "bison/omicron.y" /* yacc.c:1646  */
    {
			escribir_subseccion_data(salida);
			escribir_cabecera_bss(salida);
			simbolos_main = (simbolo_p *)ht_get_values(simbolos->main_principal);
			for(int i=0;simbolos_main[i]!=NULL;i++){
				nombre_actual_simbolo = simbolos_main[i]->nombre;
				escribe_variables(salida, nombre_actual_simbolo, simbolos_main[i]->tipo, simbolos_main[i]->tamanio > 0 ? simbolos_main[i]->tamanio : 1);
				free(nombre_actual_simbolo);
			}
			escribe_cabecera(salida);
		}
#line 1638 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 4:
#line 236 "bison/omicron.y" /* yacc.c:1646  */
    {
			escribir_inicio_main(salida);
		}
#line 1646 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 5:
#line 241 "bison/omicron.y" /* yacc.c:1646  */
    {
			imprimir_error(salida);
		}
#line 1654 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 6:
#line 246 "bison/omicron.y" /* yacc.c:1646  */
    {
			simbolos = createSimbolos("Programa");
			if (simbolos->main_principal == NULL){
				fprintf(salida, "Error al inicializar la tabla\n");
				return -1;
			}
		}
#line 1666 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 7:
#line 257 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: declaraciones: declaracion\n");
		}
#line 1674 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 8:
#line 262 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: declaraciones: declaracion declaraciones\n");
		}
#line 1682 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 9:
#line 268 "bison/omicron.y" /* yacc.c:1646  */
    {
			tamanio_vector_actual =0;
			fprintf(sintactico,";R: declaracion: modificadores_acceso clase identificadores ';'\n");
		}
#line 1691 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 10:
#line 274 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: declaracion: modificadores_acceso declaracion_clase \n");
		}
#line 1699 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 11:
#line 280 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: modificadores_acceso: \n");
		}
#line 1707 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 12:
#line 285 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,"TOK_HIDDEN TOK_UNIQUE\n");
		}
#line 1715 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 13:
#line 290 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,"TOK_SECRET TOK_UNIQUE\n");
		}
#line 1723 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 14:
#line 295 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,"TOK_EXPOSED TOK_UNIQUE\n");
		}
#line 1731 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 15:
#line 300 "bison/omicron.y" /* yacc.c:1646  */
    {
		}
#line 1738 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 16:
#line 304 "bison/omicron.y" /* yacc.c:1646  */
    {
		}
#line 1745 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 17:
#line 308 "bison/omicron.y" /* yacc.c:1646  */
    {
		}
#line 1752 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 18:
#line 312 "bison/omicron.y" /* yacc.c:1646  */
    {
		}
#line 1759 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 19:
#line 317 "bison/omicron.y" /* yacc.c:1646  */
    {
			clase_actual=ESCALAR;
			fprintf(sintactico,";R: clase: clase_escalar\n");
		}
#line 1768 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 20:
#line 323 "bison/omicron.y" /* yacc.c:1646  */
    {
			clase_actual=VECTOR;
			fprintf(sintactico,";R: clase: clase_vector\n");
		}
#line 1777 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 21:
#line 329 "bison/omicron.y" /* yacc.c:1646  */
    {
			clase_actual=OBJETO;
			fprintf(sintactico,";R: clase: clase_objeto\n");
		}
#line 1786 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 22:
#line 337 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: declaracion_clase: modificadores_clase TOK_CLASS TOK_IDENTIFICADOR TOK_INHERITS identificadores '{' declaraciones funciones '}'\n");
		}
#line 1794 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 23:
#line 342 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: declaracion_clase: modificadores_clase TOK_CLASS TOK_IDENTIFICADOR '{' declaraciones funciones '}'\n");
		}
#line 1802 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 24:
#line 348 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: modificadores_clase: \n");
		}
#line 1810 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 25:
#line 354 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: clase_escalar: tipo\n");
		}
#line 1818 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 26:
#line 360 "bison/omicron.y" /* yacc.c:1646  */
    {
			tipo_actual = INT;
			fprintf(sintactico,";R: tipo: TOK_INT\n");
		}
#line 1827 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 27:
#line 366 "bison/omicron.y" /* yacc.c:1646  */
    {

			tipo_actual = BOOLEAN;
			fprintf(sintactico,";R: tipo: TOK_BOOLEAN\n");
		}
#line 1837 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 28:
#line 374 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: clase_objeto: '{' TOK_IDENTIFICADOR '}'\n");
		}
#line 1845 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 29:
#line 380 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: clase_vector: array tipo '[' TOK_CONSTANTE_ENTERA ']'\n");
			tamanio_vector_actual = (yyvsp[-1].atributos).valor_entero;

			if ((tamanio_vector_actual < 1) || (tamanio_vector_actual> MAX_TAM_VECTOR)){
				printf("****Error semantico en lin %d: El tamanio del vector excede del maximo o es menor que 1.\n", linea);
				return -1;
			}
		}
#line 1859 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 30:
#line 392 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: identificadores: TOK_IDENTIFICADOR\n");
		}
#line 1867 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 31:
#line 397 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: identificadores: TOK_IDENTIFICADOR ',' identificadores\n");
		}
#line 1875 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 32:
#line 403 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: funciones: funcion funciones\n");
		}
#line 1883 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 33:
#line 408 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: funciones: \n");
		}
#line 1891 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 34:
#line 414 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: funcion: TOK_FUNCTION modificadores_acceso tipo_retorno TOK_IDENTIFICADOR ");
			if(buscarIdNoCualificado(simbolos, (yyvsp[0].atributos).lexema, "main", &s, id_ambito)==ERROR){
				for(int i=0; i<=num_parametros_actual;i++){
					tipos_parametros[i]=0;
				}
				num_variables_locales_actual = 0;
				pos_variable_local_actual = 1;
				num_parametros_actual = 0;
				pos_parametro_actual = 0;
				fn_return = 0;
				tipo_retorno = tipo_actual;
				(yyval.atributos).tipo= tipo_retorno;
				strcpy ((yyval.atributos).lexema, (yyvsp[0].atributos).lexema);
			}
			else{
				printf("****Error semantico en lin %d: Declaracion duplicada.\n", linea);
				return -1;
			}
		}
#line 1916 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 35:
#line 436 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico, "'(' parametros_funcion ')' ");
			nombre_funcion = crearNombreFuncion((yyvsp[-3].atributos).lexema, num_parametros_actual, tipos_parametros);
			nombre_prefijo = addPrefijo("main", nombre_funcion);
			nuevoSimboloEnMain(simbolos, nombre_prefijo,0,FUNCION,0,0,num_parametros_actual,0,0,0,0,0,0,0,0,(yyvsp[-3].atributos).tipo,0,0,0,EXPOSED,0,0,0,0,0,0,0,tipos_parametros);

			iniciaLocal(simbolos, nombre_funcion);
			free(nombre_prefijo);
			for(int i =0; i<num_parametros_actual; i++){
				nombre_prefijo = addPrefijo(nombre_funcion, nombres_parametros[i]);
				nuevoSimboloEnMain(simbolos, nombre_prefijo, PARAMETRO, tipos_parametros[i],0,0,0,0,0,i,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL);
				free(nombre_prefijo);
			}

			if(simbolos->main_local == NULL){
				fprintf(sintactico, "Error al inicializar la tabla\n");
				return -1;
			}
			if(buscarIdNoCualificado(simbolos, nombre_funcion, "main", &s, id_ambito)){
				s->numero_parametros = num_parametros_actual;
				s->numero_variables_locales = num_variables_locales_actual;
			}
			(yyval.atributos).tipo = (yyvsp[-3].atributos).tipo;
			strcpy((yyval.atributos).lexema, nombre_funcion);
		}
#line 1946 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 36:
#line 463 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico, "'{' declaraciones_funcion ");
			nombre_prefijo = addPrefijo("main", (yyvsp[-2].atributos).lexema);
			gc_inicio_cuerpo_funcion (salida, nombre_prefijo, num_variables_locales_actual);
			(yyval.atributos).tipo = (yyvsp[-2].atributos).tipo;

		}
#line 1958 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 37:
#line 474 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico, "sentencias '}'\n");
			cerrarLocal(simbolos);
			for(int i=0; i<num_parametros_llamada_actual; i++){
				tipos_parametros[num_parametros_llamada_actual]=0;
			}
			simbolos->main_local=NULL;
			(yyval.atributos).tipo = (yyvsp[-2].atributos).tipo;
			if(fn_return==0){
				printf("****Error: funcion %s sin sentencia return\n", (yyvsp[-2].atributos).lexema);
				return -1;
			}
		}
#line 1976 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 38:
#line 490 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: tipo_retorno: TOK_NONE\n");
		}
#line 1984 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 39:
#line 495 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: tipo_retorno: tipo\n");
		}
#line 1992 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 40:
#line 501 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: parametros_funcion: parametro_funcion resto_parametros_funcion\n");
		}
#line 2000 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 41:
#line 506 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: parametros_funcion: \n");
		}
#line 2008 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 42:
#line 512 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: resto_parametros_funcion: parametro_funcion resto_parametros_funcion\n");
		}
#line 2016 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 43:
#line 517 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: resto_parametros_funcion: \n");
		}
#line 2024 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 44:
#line 523 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: parametro_funcion: tipo TOK_IDENTIFICADOR\n");
		}
#line 2032 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 45:
#line 529 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: declaraciones_funcion: declaraciones\n");
		}
#line 2040 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 46:
#line 534 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: declaraciones_funcion:\n");
		}
#line 2048 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 47:
#line 540 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: sentencias: sentencia\n");
		}
#line 2056 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 48:
#line 545 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: sentencias: sentencia sentencias\n");
		}
#line 2064 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 49:
#line 551 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: sentencia: sentencia_simple ';'\n");
		}
#line 2072 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 50:
#line 556 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: sentencia: bloque\n");
		}
#line 2080 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 51:
#line 562 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: sentencia_simple: asignacion\n");
		}
#line 2088 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 52:
#line 567 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: sentencia_simple: lectura\n");
		}
#line 2096 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 53:
#line 572 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: sentencia_simple: escritura\n");
		}
#line 2104 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 54:
#line 577 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: sentencia_simple: retorno_funcion\n");
		}
#line 2112 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 55:
#line 582 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: sentencia_simple: identificador_clase '.' TOK_IDENTIFICADOR '(' lista_expresiones ')'\n");
		}
#line 2120 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 56:
#line 587 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: sentencia_simple: TOK_IDENTIFICADOR '(' lista_expresiones ')'\n");
		}
#line 2128 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 57:
#line 592 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: sentencia_simple: destruir_objeto\n");
		}
#line 2136 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 58:
#line 598 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: destruir_objeto: TOK_DISCARD TOK_IDENTIFICADOR\n");
		}
#line 2144 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 59:
#line 604 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: bloque: condicional\n");
		}
#line 2152 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 60:
#line 609 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: bloque: bucle\n");
		}
#line 2160 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 61:
#line 614 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: bloque: for\n");
		}
#line 2168 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 62:
#line 619 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: bloque: switch\n");
		}
#line 2176 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 63:
#line 627 "bison/omicron.y" /* yacc.c:1646  */
    {
	        for_final(salida, addPrefijo("main", (yyvsp[-2].atributos).lexema) ,(yyvsp[-2].atributos).etiqueta);
    	}
#line 2184 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 64:
#line 634 "bison/omicron.y" /* yacc.c:1646  */
    {
	        if ((yyvsp[-6].atributos).es_direccion == 1 || (yyvsp[-6].atributos).tipo != BOOLEAN) {
	            printf("****Error semántico en lin %d: Bucle con condicion de tipo int (%s)\n", linea, (yyvsp[-8].atributos).lexema);

	        }

	        if (buscarIdNoCualificado(simbolos, (yyvsp[-6].atributos).lexema, "main", &s, id_ambito)) {
	            (yyvsp[-4].atributos).tipo = s->tipo;
	        }
	        else {
	            printf("****Error semántico en lin %d: Acceso a variable no declarada (%s)\n", linea, (yyvsp[-8].atributos).lexema);
	        }

	        if ((yyvsp[-4].atributos).tipo != ENTERO) {
	            printf("****Error semántico en lin %d: Indice de bucle no entero (%s)\n", linea, (yyvsp[-4].atributos).lexema);
	        }

	        strcpy((yyval.atributos).lexema, (yyvsp[-8].atributos).lexema);
	        (yyval.atributos).etiqueta = (yyvsp[-8].atributos).etiqueta;
	        for_medio(salida, (yyvsp[-6].atributos).es_direccion, (yyvsp[-8].atributos).etiqueta);
	    }
#line 2210 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 65:
#line 658 "bison/omicron.y" /* yacc.c:1646  */
    {
        	strcpy((yyval.atributos).lexema, (yyvsp[0].atributos).lexema);
        	for_ini(salida, etiqueta);
        	(yyval.atributos).etiqueta = etiqueta;
	        etiqueta++;
    	}
#line 2221 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 66:
#line 667 "bison/omicron.y" /* yacc.c:1646  */
    {   
    	    switch_fin(salida, switch_etiqueta);
   		 }
#line 2229 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 67:
#line 672 "bison/omicron.y" /* yacc.c:1646  */
    {
	        if (buscarIdNoCualificado(simbolos, (yyvsp[-2].atributos).lexema, "main", &s, id_ambito)==ERROR) {
	            printf("****Error semántico en lin %d: Acceso a variable no declarada (%s)\n", linea, (yyvsp[-2].atributos).lexema);
	        }
	        case_cont = 0;
	        strcpy (switch_var, (yyvsp[-2].atributos).lexema);
	        switch_etiqueta = etiqueta;
	        etiqueta ++;
	        switch_ini(salida);
    	}
#line 2244 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 68:
#line 684 "bison/omicron.y" /* yacc.c:1646  */
    {
	    }
#line 2251 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 69:
#line 688 "bison/omicron.y" /* yacc.c:1646  */
    {
	    }
#line 2258 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 70:
#line 692 "bison/omicron.y" /* yacc.c:1646  */
    {
	    }
#line 2265 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 71:
#line 696 "bison/omicron.y" /* yacc.c:1646  */
    {
	        case_cont ++;
	        escribir_operando(salida, addPrefijo("main",switch_var), 1);
	        switch_caso(salida, switch_var, switch_etiqueta, case_cont, ultimo);
	    }
#line 2275 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 72:
#line 703 "bison/omicron.y" /* yacc.c:1646  */
    {
	        switch_fin_caso(salida, switch_etiqueta, case_cont);
	    }
#line 2283 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 73:
#line 708 "bison/omicron.y" /* yacc.c:1646  */
    {
			if (simbolos->main_local != NULL){

				if(buscarIdNoCualificado(simbolos, (yyvsp[-2].atributos).lexema, "main", &s, id_ambito)==ERROR){
					printf("****Error semántico en lin %d: Acceso a variable no declarada (%s)\n", linea, (yyvsp[-2].atributos).lexema);
					return -1;
				}

				if (s->tipo != (yyvsp[0].atributos).tipo){
					printf("****Error semántico en lin %d: Asignacion incompatible.\n", linea);
					return -1;
		    	}

			    if (s->clase == PARAMETRO){
			        gc_identificador_asignacion_local(salida, (yyvsp[0].atributos).es_direccion, s->clase, num_parametros_actual, s->posicion_parametro);
			    } else {
			        gc_identificador_asignacion_local(salida, (yyvsp[0].atributos).es_direccion, s->clase, num_variables_locales_actual, s->posicion_variable_local);
				}
			}
			else{
				if(buscarIdNoCualificado(simbolos, (yyvsp[-2].atributos).lexema, "main", &s, id_ambito)){
					if (s->tipo != (yyvsp[0].atributos).tipo){
						printf("****Error semántico en lin %d: Asignacion incompatible.\n", linea);
						return -1;
		    		}
					gc_asigexp_ident(salida, (yyvsp[0].atributos).es_direccion, s->id);
				}
				else{
					printf("****Error semántico en lin %d: Acceso a variable no declarada (%s)\n", linea, (yyvsp[-2].atributos).lexema);
				}
				fprintf(sintactico,";R: asignacion:  TOK_IDENTIFICADOR '=' exp\n");
				}
			}
#line 2321 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 74:
#line 743 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: asignacion: elemento_vector '=' exp\n");
			if ((yyvsp[-2].atributos).tipo != (yyvsp[0].atributos).tipo){
				printf("****Error semántico en lin %d: Asignacion incompatible\n", linea);
				return -1;
			}
			gc_asignar_exp_a_elementovector(salida, (yyvsp[0].atributos).es_direccion);
			(yyval.atributos).tipo=(yyvsp[-2].atributos).tipo;
			(yyval.atributos).es_direccion = 0;
		}
#line 2336 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 75:
#line 755 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: asignacion: elemento_vector '=' TOK_INSTANCE_OF TOK_IDENTIFICADOR '(' lista_expresiones ')'\n");
		}
#line 2344 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 76:
#line 760 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: asignacion: TOK_IDENTIFICADOR '=' TOK_INSTANCE_OF TOK_IDENTIFICADOR '(' lista_expresiones ')'\n");
		}
#line 2352 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 77:
#line 765 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: asignacion: identificador_clase '.' TOK_IDENTIFICADOR '=' exp\n");
		}
#line 2360 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 78:
#line 771 "bison/omicron.y" /* yacc.c:1646  */
    {
			if((yyvsp[-1].atributos).tipo != INT){
				printf("****Error semántico en lin %d: El indice en una operacion de indexacion tiene que ser de tipo entero.\n", linea);
				return -1;
			}

			fprintf(sintactico,";R: elemento_vector: TOK_IDENTIFICADOR '[' exp ']'\n");
			if(simbolos->main_local !=NULL){
				if(buscarIdNoCualificado(simbolos, (yyvsp[-3].atributos).lexema, "main", &s, id_ambito)==ERROR){
					printf("****Error semantico en lin %d: Acceso a variable no declarada\n", linea);
				}
			}else{
				if(buscarIdNoCualificado(simbolos, (yyvsp[-3].atributos).lexema, "main", &s, id_ambito)==ERROR){
					printf("****Error semantico en lin %d: Acceso a variable no declarada\n", linea);
				}
			}

			
			if (s->clase != VECTOR){
				printf("****Error semántico en lin %d: Intento de indexacion de una variable que no es de tipo vector.\n", linea);
				return -1;
			}

			gc_escribir_elemento_vector(salida, (yyvsp[-1].atributos).es_direccion, s->id, s->tamanio);
			(yyval.atributos).es_direccion = 1;
			(yyval.atributos).tipo = s->tipo;
			
		}
#line 2393 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 79:
#line 802 "bison/omicron.y" /* yacc.c:1646  */
    {

			fprintf(sintactico,";R: condicional: if_exp '(' exp ')' '{' sentencias '}'\n");
			gc_ifthen_fin(salida, (yyvsp[-2].atributos).etiqueta);
		}
#line 2403 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 80:
#line 809 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: condicional: if_exp_sentencias TOK_ELSE '{' sentencias '}'\n");
			gc_ifthenelse_fin(salida, (yyvsp[-4].atributos).etiqueta);
		}
#line 2412 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 81:
#line 816 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: if_exp_sentencias: if_exp sentencias '}'\n");
			(yyval.atributos).etiqueta = (yyvsp[-2].atributos).etiqueta;
			gc_ifthenelse_fin_then(salida, (yyvsp[-2].atributos).etiqueta);
		}
#line 2422 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 82:
#line 824 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: if_exp: TOK_IF '(' exp ')' '{'\n");
			if ((yyvsp[-2].atributos).tipo != BOOLEAN){
				if((yyvsp[-2].atributos).valor_entero != 0){
					printf("****Error semántico en lin %d: Comparacion con condicion de tipo int.\n", linea);
				}else{
					printf("****Error semántico en lin %d: Comparacion con operandos boolean.\n", linea);
				}
				return -1;
			}

			(yyval.atributos).etiqueta = etiqueta++;
			gc_ifthen_inicio(salida, (yyvsp[-2].atributos).es_direccion, (yyval.atributos).etiqueta);
			
		}
#line 2442 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 83:
#line 841 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: bucle: TOK_WHILE '(' exp ')' '{' sentencias '}'\n");
			etiqueta = etiquetas[cima_etiquetas];
			gc_while_fin(salida, etiqueta);
			cima_etiquetas --;
		}
#line 2453 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 84:
#line 849 "bison/omicron.y" /* yacc.c:1646  */
    {
			if((yyvsp[-2].atributos).tipo != BOOLEAN){
	 			if((yyvsp[-2].atributos) .valor_entero != 0){
					printf("****Error semántico en lin %d: Bucle while con condicion de tipo int.\n", linea);
				}else{
					printf("****Error semántico en lin %d: Bucle while con operandos boolean.\n", linea);
				}
				return -1;
			}
			etiqueta = etiquetas[cima_etiquetas];
			gc_while_exp_pila(salida, (yyvsp[-2].atributos).es_direccion, etiqueta);
		}
#line 2470 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 85:
#line 864 "bison/omicron.y" /* yacc.c:1646  */
    {
			getiqueta++;
        	cima_etiquetas++;
        	etiquetas[cima_etiquetas]=getiqueta;
        	etiqueta = getiqueta;
			gc_while_inicio(salida, etiqueta);
		}
#line 2482 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 86:
#line 874 "bison/omicron.y" /* yacc.c:1646  */
    {
			if(simbolos->main_local != NULL){
				if(buscarIdNoCualificado(simbolos, (yyvsp[0].atributos).lexema, "main", &s, id_ambito)==ERROR){
					printf("****Error semántico en lin %d: Acceso a variable no declarada (%s).\n", linea, (yyvsp[0].atributos).lexema);
					return -1;
				}
				
				if(s->clase == PARAMETRO){
					gc_scanf_funcion(salida, num_parametros_actual, s->posicion_parametro, s->clase, s->tipo);
				}
				else{
					gc_scanf_funcion(salida, num_variables_locales_actual, s->posicion_variable_local, s->clase, s->tipo);
				}
			}else{
				if(buscarIdNoCualificado(simbolos, (yyvsp[0].atributos).lexema, "main", &s, id_ambito)==ERROR){
					printf("****Error semántico en lin %d: Acceso a variable no declarada (%s).\n", linea, (yyvsp[0].atributos).lexema);
					return -1;
				}
				if(s->clase == VECTOR){
					printf("****Error semántico en lin %d: Variable local de tipo no escalar.\n", linea);
					return -1;
				}
				gc_lectura(salida, s->id, s->tipo);
			}
			fprintf(sintactico,";R: lectura: TOK_SCANF TOK_IDENTIFICADOR\n");
		}
#line 2513 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 87:
#line 902 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: lectura: TOK_SCANF elemento_vector\n");
		}
#line 2521 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 88:
#line 908 "bison/omicron.y" /* yacc.c:1646  */
    {
			gc_printf(salida, (yyvsp[0].atributos).es_direccion, (yyvsp[0].atributos).tipo);
			fprintf(sintactico,";R: escritura: TOK_PRINTF exp\n");
		}
#line 2530 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 89:
#line 916 "bison/omicron.y" /* yacc.c:1646  */
    {
			en_explist = 1;
			strcpy((yyval.atributos).lexema,(yyvsp[0].atributos).lexema);
		}
#line 2539 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 90:
#line 922 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: retorno_funcion: TOK_RETURN exp\n");
			if (buscarIdNoCualificado(simbolos, nombre_funcion, "main", &s, id_ambito)==ERROR){
				printf("****Error semántico en lin %d: Acceso a variable no declarada (%s).\n", linea, nombre_funcion);
				return -1;
			}
			if ((yyvsp[0].atributos).tipo != tipo_retorno){
				printf("****Error semántico en lin %d: Asignacion incompatible.\n", linea);
				return -1;
			}
			if ((yyvsp[0].atributos).es_direccion != 0 && (yyvsp[0].atributos).es_direccion != 1){
				printf("****Error semántico en lin %d: Direccion incorrecta.\n", linea);
				return -1;
			}
			fn_return++;
			gc_final_cuerpo_funcion(salida, (yyvsp[0].atributos).es_direccion);
		}
#line 2561 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 91:
#line 941 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: retorno_funcion: TOK_RETURN TOK_NONE\n");
		}
#line 2569 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 92:
#line 947 "bison/omicron.y" /* yacc.c:1646  */
    {
			if ((yyvsp[-2].atributos).tipo != INT || (yyvsp[0].atributos).tipo != INT){
				printf("****Error semántico en lin %d: Operacion aritmetica con operandos boolean.\n", linea);
				return -1;
			}
			gc_suma_enteros(salida, (yyvsp[-2].atributos).es_direccion, (yyvsp[0].atributos).es_direccion);
			(yyval.atributos).es_direccion = 0;
			(yyval.atributos).tipo = INT;
			fprintf(sintactico,";R: exp: exp '+' exp\n");
		}
#line 2584 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 93:
#line 959 "bison/omicron.y" /* yacc.c:1646  */
    {
			if ((yyvsp[-2].atributos).tipo != INT || (yyvsp[0].atributos).tipo != INT){
				printf("****Error semántico en lin %d: Operacion aritmetica con operandos boolean.\n", linea);
				return -1;
			}
			gc_resta_enteros(salida, (yyvsp[-2].atributos).es_direccion, (yyvsp[0].atributos).es_direccion);
			(yyval.atributos).es_direccion = 0;
			(yyval.atributos).tipo = INT;
			fprintf(sintactico,";R: exp: exp '-' exp\n");
		}
#line 2599 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 94:
#line 971 "bison/omicron.y" /* yacc.c:1646  */
    {
			if((yyvsp[-2].atributos).tipo != INT || (yyvsp[0].atributos).tipo != INT){
				printf("****Error semántico en lin %d: Operacion aritmetica con operandos boolean.\n", linea);
				return -1;
			}
			fprintf(sintactico,";R: exp: exp '^' exp\n");
			(yyval.atributos).es_direccion = 0;
			(yyval.atributos).tipo = INT;
			gc_exponencial_enteros(salida, (yyvsp[-2].atributos).es_direccion, (yyvsp[0].atributos).es_direccion, etiqueta_exponencial);
			etiqueta_exponencial ++;
		}
#line 2615 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 95:
#line 984 "bison/omicron.y" /* yacc.c:1646  */
    {
			if ((yyvsp[-2].atributos).tipo != INT || (yyvsp[0].atributos).tipo != INT){
				printf("****Error semántico en lin %d: Operacion aritmetica con operandos boolean.\n", linea);
				return -1;
			}
			gc_division_enteros(salida, (yyvsp[-2].atributos).es_direccion, (yyvsp[0].atributos).es_direccion);
			(yyval.atributos).es_direccion = 0;
			(yyval.atributos).tipo = INT;
			fprintf(sintactico,";R: exp: exp '/' exp\n");
		}
#line 2630 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 96:
#line 996 "bison/omicron.y" /* yacc.c:1646  */
    {
			if ((yyvsp[-2].atributos).tipo != INT || (yyvsp[0].atributos).tipo != INT){
				printf("****Error semántico en lin %d: Operacion aritmetica con operandos boolean.\n", linea);
				return -1;
			}
			gc_producto_enteros(salida, (yyvsp[-2].atributos).es_direccion, (yyvsp[0].atributos).es_direccion);
			(yyval.atributos).es_direccion = 0;
			(yyval.atributos).tipo = INT;
			fprintf(sintactico,";R: exp: exp '*' exp\n");
		}
#line 2645 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 97:
#line 1008 "bison/omicron.y" /* yacc.c:1646  */
    {
			if ((yyvsp[0].atributos).tipo!=INT){
				printf("****Error semántico en lin %d: Operacion aritmetica con operandos boolean.\n", linea);
				return -1;
			}
			gc_negacion_entero(salida, (yyvsp[0].atributos).es_direccion);
			(yyval.atributos).es_direccion = 0;
			(yyval.atributos).tipo = INT;
			fprintf(sintactico,";R: exp: '-' exp\n");
		}
#line 2660 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 98:
#line 1020 "bison/omicron.y" /* yacc.c:1646  */
    {
			if ((yyvsp[-2].atributos).tipo != BOOLEAN || (yyvsp[0].atributos).tipo != BOOLEAN) {
				printf("****Error semántico en lin %d: Operacion logica con operandos int.\n", linea);
				return -1;
			}
			gc_and_logico(salida, (yyvsp[-2].atributos).es_direccion, (yyvsp[0].atributos).es_direccion);
			(yyval.atributos).es_direccion = 0;
			(yyval.atributos).tipo = BOOLEAN;
			fprintf(sintactico,";R: exp: exp TOK_AND exp\n");
		}
#line 2675 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 99:
#line 1032 "bison/omicron.y" /* yacc.c:1646  */
    {
			if ((yyvsp[-2].atributos).tipo!=BOOLEAN || (yyvsp[0].atributos).tipo!=BOOLEAN) {
				printf("****Error semántico en lin %d: Operacion logica con operandos int.\n", linea);
				return -1;
			}
			gc_or_logico(salida, (yyvsp[-2].atributos).es_direccion, (yyvsp[0].atributos).es_direccion);
			(yyval.atributos).es_direccion = 0;
			(yyval.atributos).tipo = BOOLEAN;
			fprintf(sintactico,";R: exp: exp TOK_OR exp\n");
		}
#line 2690 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 100:
#line 1044 "bison/omicron.y" /* yacc.c:1646  */
    {
			if ((yyvsp[0].atributos).tipo!=BOOLEAN) {
				printf("****Error semántico en lin %d: Operacion logica con operandos int.\n", linea);
				return -1;
			}
			gc_not_logico(salida, (yyvsp[0].atributos).es_direccion, etiqueta);
			(yyval.atributos).es_direccion = 0;
			(yyval.atributos).tipo = BOOLEAN;
			etiqueta++;
			fprintf(sintactico,";R: exp: '!' exp \n");
		}
#line 2706 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 101:
#line 1057 "bison/omicron.y" /* yacc.c:1646  */
    {
			if(simbolos->main_local == NULL){
				if(buscarIdNoCualificado(simbolos, (yyvsp[0].atributos).lexema, "main", &s, id_ambito)==ERROR){
					printf("****Error semántico en lin %d: Acceso a variable no declarada (%s).\n", linea, (yyvsp[0].atributos).lexema);
					return -1;
				}
				if(en_explist == 0){
					fprintf (salida, "\t\tpush dword _%s\n", s->id);
				}else{
					fprintf (salida, "\t\tpush dword [_%s]\n", s->id);
				}
			}else{
				if(buscarIdNoCualificado(simbolos, (yyvsp[0].atributos).lexema, "main", &s, id_ambito)==ERROR){
					printf("****Error semántico en lin %d: Acceso a variable no declarada (%s).\n", linea, (yyvsp[0].atributos).lexema);
					return -1;
				}
				if(s->clase == PARAMETRO){
					gc_escribirParametro(salida, s->posicion_parametro, num_parametros_actual);
				}else{
					gc_escribirVariableLocal(salida, s->posicion_variable_local);
				}
			}
			(yyval.atributos).tipo = s->tipo;
			(yyval.atributos).es_direccion = 1;

		}
#line 2737 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 102:
#line 1085 "bison/omicron.y" /* yacc.c:1646  */
    {
			(yyval.atributos).tipo = (yyvsp[0].atributos).tipo;
			(yyval.atributos).es_direccion = (yyvsp[0].atributos).es_direccion;
			fprintf(sintactico,";R: exp: constante\n");
		}
#line 2747 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 103:
#line 1092 "bison/omicron.y" /* yacc.c:1646  */
    {
			(yyval.atributos).tipo = (yyvsp[-1].atributos).tipo;
			(yyval.atributos).es_direccion = (yyvsp[-1].atributos).es_direccion;
			fprintf(sintactico,";R: exp: '(' exp ')'\n");
		}
#line 2757 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 104:
#line 1099 "bison/omicron.y" /* yacc.c:1646  */
    {
			(yyval.atributos).tipo = (yyvsp[-1].atributos).tipo;
			(yyval.atributos).es_direccion = (yyvsp[-1].atributos).es_direccion;
			fprintf(sintactico,";R: exp: '(' comparacion ')'\n");
		}
#line 2767 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 105:
#line 1106 "bison/omicron.y" /* yacc.c:1646  */
    {
			(yyval.atributos).tipo = (yyvsp[0].atributos).tipo;
			(yyval.atributos).es_direccion = (yyvsp[0].atributos).es_direccion;
			fprintf(sintactico,";R: exp: '(' elemento_vector ')'\n");
		}
#line 2777 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 106:
#line 1113 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: exp: TOK_IDENTIFICADOR '(' lista_expresiones ')'\n");
			
			int aux[100];
			int j=0;
			for (int i =num_parametros_llamada_actual-1; i>=0; i--)	{
				aux[j]=tipos_parametros[i];
				j++;
			}
			for (int i = 0; i <num_parametros_llamada_actual; ++i){
				tipos_parametros[i]=0;
			}
			for (int i=0; i<num_parametros_llamada_actual; ++i){
				tipos_parametros[i]=aux[i];
			}
			for (int i = 0; i <num_parametros_llamada_actual; ++i){
				aux[i]=0;
			}
			nombre_funcion = crearNombreFuncion((yyvsp[-3].atributos).lexema, num_parametros_llamada_actual, tipos_parametros);
			nombre_prefijo= addPrefijo("main", nombre_funcion);
			if(buscarIdNoCualificado(simbolos, nombre_funcion, "main", &s, id_ambito)==ERROR){
				printf("****Error semántico en lin %d: Acceso a funcion no declarada, revisar parametros o nombre de la funcion(%s).\n", linea, (yyvsp[-3].atributos).lexema);
				return -1;
			}
			if (s->tipo != FUNCION){
				printf("****Error semántico en lin %d: Identificador no es de categoriaegoria funcion\n", linea);
				return -1;
			}

			if (en_explist == 1){
				printf("****Error semántico en lin %d: No esta permitido el uso de llamadas a funciones como parametros de otras funciones.\n", linea);
				return -1;
			}

			/*Comprobamos que el numero de parametros es correcto*/
			if (s->numero_parametros != num_parametros_llamada_actual){
				printf("****Error semántico en lin %d: Numero incorrecto de parametros en llamada a funcion.\n", linea);
				return -1;
			}

			(yyval.atributos).tipo = s->TIPO_RETORNO;
			(yyval.atributos).es_direccion = 0;
			gc_llamarfuncion(salida, s->id, s->numero_parametros);
			num_parametros_actual=0;
			for (int i=0; i<num_parametros_llamada_actual; ++i){
				tipos_parametros[i]=aux[i];
			}
			num_parametros_llamada_actual = 0;

		}
#line 2832 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 107:
#line 1165 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: exp: identificador_clase '.' TOK_IDENTIFICADOR '(' lista_expresiones ')'\n");
		}
#line 2840 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 108:
#line 1170 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: exp: identificador_clase '.' TOK_IDENTIFICADOR\n");
		}
#line 2848 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 109:
#line 1177 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: identificador_clase: TOK_IDENTIFICADOR\n");
		}
#line 2856 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 110:
#line 1182 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: identificador_clase: TOK_ITSELF\n");
		}
#line 2864 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 111:
#line 1188 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: lista_expresiones: exp resto_lista_expresiones\n");
			en_explist = 0;
			tipos_parametros[num_parametros_llamada_actual]=(yyvsp[-1].atributos).tipo;
			num_parametros_llamada_actual++;
		}
#line 2875 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 112:
#line 1196 "bison/omicron.y" /* yacc.c:1646  */
    {
			en_explist=0;
			fprintf(sintactico,";R: lista_expresiones: \n");
		}
#line 2884 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 113:
#line 1203 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: resto_lista_expresiones: exp resto_lista_expresiones\n");
			tipos_parametros[num_parametros_llamada_actual]=(yyvsp[-1].atributos).tipo;
			num_parametros_llamada_actual++;
		}
#line 2894 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 114:
#line 1210 "bison/omicron.y" /* yacc.c:1646  */
    {
			fprintf(sintactico,";R: resto_lista_expresiones: \n");
		}
#line 2902 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 115:
#line 1216 "bison/omicron.y" /* yacc.c:1646  */
    {
			if ((yyvsp[-2].atributos).tipo!=INT || (yyvsp[0].atributos).tipo!=INT){
				printf("****Error semántico en lin %d: Comparacion con operandos boolean.\n", linea);
				return -1;
			}
			gc_igual(salida, (yyvsp[-2].atributos).es_direccion, (yyvsp[0].atributos).es_direccion, etiqueta);
			(yyval.atributos).etiqueta = etiqueta++;
			(yyval.atributos).es_direccion = 0;
			(yyval.atributos).tipo = BOOLEAN;
			fprintf(sintactico,";R: comparacion: exp TOK_IGUAL exp\n");
		}
#line 2918 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 116:
#line 1229 "bison/omicron.y" /* yacc.c:1646  */
    {
			if ((yyvsp[-2].atributos).tipo!=INT || (yyvsp[0].atributos).tipo!=INT){
				printf("****Error semántico en lin %d: Comparacion con operandos boolean.\n", linea);
				return -1;
			}
			gc_distinto(salida, (yyvsp[-2].atributos).es_direccion, (yyvsp[0].atributos).es_direccion, etiqueta);
			(yyval.atributos).etiqueta = etiqueta++;
			(yyval.atributos).es_direccion = 0;
			(yyval.atributos).tipo = BOOLEAN;
			fprintf(sintactico,";R: comparacion: exp TOK_DISTINTO exp\n");
		}
#line 2934 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 117:
#line 1242 "bison/omicron.y" /* yacc.c:1646  */
    {
			if ((yyvsp[-2].atributos).tipo!=INT || (yyvsp[0].atributos).tipo!=INT){
				printf("****Error semántico en lin %d: Comparacion con operandos boolean.\n", linea);
				return -1;
			}
			gc_mayorigual(salida, (yyvsp[-2].atributos).es_direccion, (yyvsp[0].atributos).es_direccion, etiqueta);
			(yyval.atributos).etiqueta = etiqueta++;
			(yyval.atributos).es_direccion = 0;
			(yyval.atributos).tipo = BOOLEAN;
			fprintf(sintactico,";R: comparacion: exp TOK_MAYORIGUAL exp\n");
		}
#line 2950 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 118:
#line 1255 "bison/omicron.y" /* yacc.c:1646  */
    {
			if ((yyvsp[-2].atributos).tipo!=INT || (yyvsp[0].atributos).tipo!=INT){
				printf("****Error semántico en lin %d: Comparacion con operandos boolean.\n", linea);
				return -1;
			}
			gc_menorigual(salida, (yyvsp[-2].atributos).es_direccion, (yyvsp[0].atributos).es_direccion, etiqueta);
			(yyval.atributos).etiqueta = etiqueta++;
			(yyval.atributos).es_direccion = 0;
			(yyval.atributos).tipo = BOOLEAN;
			fprintf(sintactico,";R: comparacion: exp TOK_MENORIGUAL exp\n");
		}
#line 2966 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 119:
#line 1268 "bison/omicron.y" /* yacc.c:1646  */
    {
			if ((yyvsp[-2].atributos).tipo!=INT || (yyvsp[0].atributos).tipo!=INT){
				printf("****Error semántico en lin %d: Comparacion con operandos boolean.\n", linea);
				return -1;
			}
			gc_mayor(salida, (yyvsp[-2].atributos).es_direccion, (yyvsp[0].atributos).es_direccion, etiqueta);
			(yyval.atributos).etiqueta = etiqueta++;
			(yyval.atributos).es_direccion = 0;
			(yyval.atributos).tipo = BOOLEAN;
			fprintf(sintactico,";R: comparacion: exp '>' exp\n");
		}
#line 2982 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 120:
#line 1281 "bison/omicron.y" /* yacc.c:1646  */
    {
			if ((yyvsp[-2].atributos).tipo!=INT || (yyvsp[0].atributos).tipo!=INT){
				printf("****Error semántico en lin %d: Comparacion con operandos boolean.\n", linea);
				return -1;
			}
			gc_menor(salida, (yyvsp[-2].atributos).es_direccion, (yyvsp[0].atributos).es_direccion, etiqueta);
			(yyval.atributos).etiqueta = etiqueta++;
			(yyval.atributos).es_direccion = 0;
			(yyval.atributos).tipo = BOOLEAN;
			fprintf(sintactico,";R: comparacion: exp '<' exp\n");
		}
#line 2998 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 121:
#line 1295 "bison/omicron.y" /* yacc.c:1646  */
    {
			(yyval.atributos).tipo = (yyvsp[0].atributos).tipo;
			(yyval.atributos).es_direccion = (yyvsp[0].atributos).es_direccion;
			fprintf(sintactico,";R: constante: constante_logica\n");
		}
#line 3008 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 122:
#line 1302 "bison/omicron.y" /* yacc.c:1646  */
    {
			(yyval.atributos).tipo = (yyvsp[0].atributos).tipo;
			(yyval.atributos).es_direccion = (yyvsp[0].atributos).es_direccion;
			fprintf(sintactico,";R: constante: constante_entera\n");
		}
#line 3018 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 123:
#line 1310 "bison/omicron.y" /* yacc.c:1646  */
    {
			(yyval.atributos).tipo = BOOLEAN;
			(yyval.atributos).es_direccion = 0;
			fprintf(salida, "\t\tpush dword 1\n");
			fprintf(sintactico,";R: constante_logica: TOK_TRUE\n");
		}
#line 3029 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 124:
#line 1318 "bison/omicron.y" /* yacc.c:1646  */
    {
			(yyval.atributos).tipo = BOOLEAN;
			(yyval.atributos).es_direccion = 0;
			fprintf(salida, "\t\tpush dword 0\n");
			fprintf(sintactico,";R: constante_logica: TOK_FALSE\n");
		}
#line 3040 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 125:
#line 1327 "bison/omicron.y" /* yacc.c:1646  */
    {
			(yyval.atributos).tipo = INT;
			(yyval.atributos).es_direccion = 0;
			fprintf(salida, "\t\tpush dword %d\n", (yyvsp[0].atributos).valor_entero);
			fprintf(sintactico,";R: constante_entera: TOK_CONSTANTE_ENTERA\n");
		}
#line 3051 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 126:
#line 1337 "bison/omicron.y" /* yacc.c:1646  */
    {
			clase_actual = ESCALAR;
			strcpy(nombres_parametros[pos_parametro_actual], (yyvsp[0].atributos).lexema);
			tipos_parametros[pos_parametro_actual] = tipo_actual;
			pos_parametro_actual++;
		  	num_parametros_actual++;
		}
#line 3063 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;

  case 127:
#line 1346 "bison/omicron.y" /* yacc.c:1646  */
    {
			if(simbolos->main_local != NULL){
			nombre_actual_simbolo = addPrefijo(ht_get_name(simbolos->main_local), (yyvsp[0].atributos).lexema);
				if(buscarIdNoCualificado(simbolos, (yyvsp[0].atributos).lexema, "main", &s, id_ambito)==ERROR){
					nuevoSimboloEnMain(simbolos, nombre_actual_simbolo, clase_actual,tipo_actual,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,EXPOSED,0,0,0,0,0,0,0,NULL);
					pos_variable_local_actual++;
					num_variables_locales_actual++;
					free(nombre_actual_simbolo);
				}
			} else {
				nombre_actual_simbolo = (yyvsp[0].atributos).lexema;
				nombre_actual_simbolo = addPrefijo("main", nombre_actual_simbolo);
				if(buscarParaDeclararIdTablaSimbolosAmbitos(simbolos, nombre_actual_simbolo, &s, id_ambito)){
					printf("****Error semántico en lin %d por declaracion duplicada del elemento %s\n", linea, (yyvsp[0].atributos).lexema);
				}
				else{
					(yyvsp[0].atributos).tipo = tipo_actual;
					nuevoSimboloEnMain(simbolos, nombre_actual_simbolo, clase_actual,tipo_actual,0,1,0,0,0,0,0,tamanio_vector_actual,0,0,0,0,0,0,0,EXPOSED,0,0,0,0,0,0,0,NULL);
				}
				fprintf(sintactico,";R: identificador: TOK_IDENTIFICADOR\n");
				free(nombre_actual_simbolo);
			}
		}
#line 3091 "bison/omicron.tab.c" /* yacc.c:1646  */
    break;


#line 3095 "bison/omicron.tab.c" /* yacc.c:1646  */
      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYEMPTY : YYTRANSLATE (yychar);

  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
# define YYSYNTAX_ERROR yysyntax_error (&yymsg_alloc, &yymsg, \
                                        yyssp, yytoken)
      {
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = YYSYNTAX_ERROR;
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == 1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = (char *) YYSTACK_ALLOC (yymsg_alloc);
            if (!yymsg)
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = 2;
              }
            else
              {
                yysyntax_error_status = YYSYNTAX_ERROR;
                yymsgp = yymsg;
              }
          }
        yyerror (yymsgp);
        if (yysyntax_error_status == 2)
          goto yyexhaustedlab;
      }
# undef YYSYNTAX_ERROR
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYTERROR;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#if !defined yyoverflow || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  return yyresult;
}
#line 1370 "bison/omicron.y" /* yacc.c:1906  */


void escribe_cabecera (FILE * salida){
	escribir_segmento_codigo(salida);
	return ;
}

void escribe_variables (FILE * salida, int tipo, char* nombre, int tamanio){
	declarar_variable(salida, nombre, tipo, tamanio);
}

void imprimir_error(FILE * salida){
	escribir_fin(salida);
	return;
}

void gc_suma_enteros(FILE *salida, int es_direccion_op1, int es_direccion_op2) {
	sumar(salida, es_direccion_op1, es_direccion_op2);
	return;
}

void gc_resta_enteros(FILE *salida, int es_direccion_op1, int es_direccion_op2) {
	restar(salida, es_direccion_op1, es_direccion_op2);
	return;
}


void gc_exponencial_enteros(FILE *salida, int es_direccion_op1, int es_direccion_op2, int etiqueta_exponencial){
	exponencial(salida, es_direccion_op1, es_direccion_op2, etiqueta_exponencial);
	return;
}


void gc_division_enteros(FILE *salida, int es_direccion_op1, int es_direccion_op2) {
	dividir(salida, es_direccion_op1, es_direccion_op2);
	return;
}

void gc_producto_enteros(FILE *salida, int es_direccion_op1, int es_direccion_op2) {
	multiplicar(salida, es_direccion_op1, es_direccion_op2);
	return;
}

void gc_negacion_entero(FILE *salida, int es_direccion_op1){
	cambiar_signo(salida, es_direccion_op1);
	return;
}

void gc_and_logico(FILE *salida, int es_direccion_op1, int es_direccion_op2){
	y(salida, es_direccion_op1, es_direccion_op2);
	return;
}

void gc_or_logico(FILE *salida, int es_direccion_op1, int es_direccion_op2){
	o(salida, es_direccion_op1, es_direccion_op2);
	return;
}

void gc_not_logico(FILE *salida, int es_direccion_op1, int etiqueta){
	no(salida, es_direccion_op1, etiqueta);
	return;
}

void gc_igual(FILE *salida, int es_direccion_op1, int es_direccion_op2, int etiqueta){
	igual(salida, es_direccion_op1, es_direccion_op2, etiqueta);
	return;
}

void gc_distinto(FILE *salida, int es_direccion_op1, int es_direccion_op2, int etiqueta){
	distinto(salida, es_direccion_op1, es_direccion_op2, etiqueta);
	return;
}

void gc_menorigual(FILE *salida, int es_direccion_op1, int es_direccion_op2, int etiqueta){
	menor_igual(salida, es_direccion_op1, es_direccion_op2, etiqueta);
	return;
}

void gc_mayorigual(FILE *salida, int es_direccion_op1, int es_direccion_op2, int etiqueta){
	mayor_igual(salida, es_direccion_op1, es_direccion_op2, etiqueta);
	return;
}

void gc_menor(FILE *salida, int es_direccion_op1, int es_direccion_op2, int etiqueta){
	menor(salida, es_direccion_op1, es_direccion_op2, etiqueta);
	return;
}

void gc_mayor(FILE *salida, int es_direccion_op1, int es_direccion_op2, int etiqueta){
	mayor(salida, es_direccion_op1, es_direccion_op2, etiqueta);
	return;
}

void gc_vectores_indice(FILE *salida, int es_direccion_op1, char *lexema, int tam_vector){
	escribir_elemento_vector(salida,lexema, tam_vector, es_direccion_op1);
	return;
}


void gc_asigexp_ident(FILE *salida, int es_direccion_op1, char *lexema){
	asignar(salida, lexema, es_direccion_op1);
	return;
}


void gc_printf(FILE *salida, int es_direccion_op1, int tipo){
	escribir(salida, es_direccion_op1, tipo);
	return;
}

void gc_ifthenelse_inicio(FILE * salida, int exp_es_variable, int etiqueta){
	ifthenelse_inicio(salida, exp_es_variable, etiqueta);
	return;
}


void gc_ifthen_inicio(FILE * salida, int exp_es_variable, int etiqueta){
	ifthen_inicio(salida, exp_es_variable, etiqueta);
	return;
}


void gc_ifthen_fin(FILE* salida, int etiqueta){
    ifthen_fin(salida, etiqueta);
    return;
}


void gc_ifthenelse_fin_then(FILE* salida, int etiqueta){
    ifthenelse_fin_then(salida, etiqueta);
    return;
}

void gc_ifthenelse_fin( FILE * salida, int etiqueta){
	ifthenelse_fin(salida, etiqueta);
	return;
}


void gc_asignarDestinoPila(FILE* salida, int es_variable, char * eax, char * ebx){
	asignarDestinoEnPila(salida, es_variable);
	return;
}

void gc_scanf_funcion(FILE *salida, int num_param_actual, int posicion_parametro, int categoria, int tipo){
	if (categoria == PARAMETRO){
		escribirParametro(salida, posicion_parametro, num_param_actual);
	}else {
		escribirVariableLocal(salida, posicion_parametro);
	}

	if(tipo==INT){
		fprintf(salida,"\t\tcall scan_int\n");
	}else{
		fprintf(salida,"\t\tcall scan_boolean\n");
	}
	fprintf(salida,"\t\tadd esp,4\n");
}

void gc_lectura(FILE * salida, char * nombre, int tipo){
	leer(salida, nombre, tipo);
}

void gc_inicio_cuerpo_funcion (FILE *salida, char * lexema, int num_variable_locales){
	declararFuncion(salida, lexema, num_variable_locales);
}

void gc_final_cuerpo_funcion (FILE *salida, int esdireccion){
	retornarFuncion(salida, esdireccion);
}


void gc_escribirParametro(FILE *salida, int posicion_parametro, int num_parametros_actual){
	escribirParametro(salida, posicion_parametro, num_parametros_actual);
}

void gc_escribirVariableLocal(FILE *salida,int posicion_variable_local){
	escribirVariableLocal(salida, posicion_variable_local);
}


void gc_identificador_asignacion_local(FILE *salida, int es_direccion, int categoria, int numero_param, int posicion){
	fprintf(salida,"\t\tpop dword eax\n");
	if (es_direccion == 1)
		fprintf(salida,"\t\tmov dword eax, [eax]\n");
	if (categoria == PARAMETRO){
		fprintf(salida,"\t\tmov dword [ebp+4+4*%d], eax\n", numero_param-posicion);
	}else{
		fprintf(salida,"\t\tmov dword [ebp-4*%d], eax\n", posicion);
	}
	return;
}

void gc_asignar_exp_a_elementovector(FILE *salida, int es_direccion_op1){
	asignar_valor_vector(salida, es_direccion_op1);
	return;
}

void gc_llamarfuncion (FILE *salida, char * lexema, int num_parametros){
	llamarFuncion(salida, lexema, num_parametros);
}


void gc_escribir_elemento_vector(FILE *salida, int es_direccion_op1, char *lexema, int tam_vector){
	escribir_elemento_vector(salida,lexema, tam_vector, es_direccion_op1);
}


void gc_while_fin(FILE * salida,int  etiqueta){
	while_fin(salida, etiqueta);
}

void gc_while_inicio(FILE * salida,int  etiqueta){
	while_inicio(salida, etiqueta);
}

void gc_while_exp_pila (FILE * salida, int exp_es_variable, int etiqueta){
	while_exp_pila (salida, exp_es_variable, etiqueta);
}


void for_ini(FILE *fpasm, int etiqueta)
{
	if (!fpasm)
	{
		printf("Error del fichero (elevar)\n");
		return;
	}

	fprintf(fpasm, "for_%d:\n", etiqueta);
	return;
}

void for_medio(FILE *fpasm, int es_variable, int etiqueta)
{
	if (!fpasm)
	{
		return;
	}

	fprintf(fpasm, "\tpop eax\n");
	if (es_variable)
	{
		fprintf(fpasm, "\tmov eax, [eax]\n");
	}
	fprintf(fpasm, "\tcmp eax, 0\n");
	fprintf(fpasm, "\tje near fin_for_%d\n", etiqueta);
}

void for_final(FILE *fpasm, char *indice ,int etiqueta)
{
	if (!fpasm)
	{
		return;
	}
	fprintf(fpasm, "\tmov eax, [_%s]\n\tadd eax, 1\n\t mov [_%s], eax\n", indice, indice);
	fprintf(fpasm, "\tjmp for_%d\nfin_for_%d:\n", etiqueta, etiqueta);
	return;
}

void switch_fin(FILE *fpasm, int etiqueta) {
	if (!fpasm)
	{
		return;
	}

	fprintf(fpasm, "fin_switch_%d:\n", etiqueta);
}
void switch_ini(FILE *fpasm) {
	if (!fpasm)
	{
		return;
	}
	fprintf(fpasm, ";Switch\n");
}
void switch_caso(FILE *fpasm, char *switch_var, int etiqueta, int case_cont, int ultimo){
	if (!fpasm)
	{
		return;
	}
	fprintf(fpasm, "\tpop ecx\n\tpop eax\n");
	//Siempre es una variable ( se controla antes)
	fprintf(fpasm, "\tmov ecx, [ecx]\n");

	if (ultimo == 0)
		fprintf(fpasm, "\tcmp eax, ecx\n\tjne near switch_%d_case_%d\n", etiqueta, case_cont);
	else
		fprintf(fpasm, "\tcmp eax, ecx\n\tjne near fin_switch_%d\n", etiqueta);

}

void switch_fin_caso(FILE *fpasm, int etiqueta, int case_cont){
	fprintf(fpasm, "\tjmp fin_switch_%d\nswitch_%d_case_%d:\n", etiqueta, etiqueta, case_cont);
}

void yyerror(const char * s) {
	printf("****Error sintactico en [lin %d, col %d]\n", linea, columna);
}

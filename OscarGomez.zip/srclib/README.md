Aquí van los fuentes de las librerías implementadas (.c)

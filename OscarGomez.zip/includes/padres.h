#include "graph.h"

#ifndef _PADRES_H_
#define _PADRES_H_

#define MAX_PADRES 100

char** get_padres(graph_p grafo, char** padres, int size);

#endif // _PADRES_H_
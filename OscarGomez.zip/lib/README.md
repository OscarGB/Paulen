Aquí van las librerías compiladas (.a)

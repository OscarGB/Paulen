#include "generacion.h"

#ifndef GENERACION_RESTO_H
#define GENERACION_RESTO_H

void resto(FILE* fpasm, int es_variable_1, int es_variable_2);

#endif
